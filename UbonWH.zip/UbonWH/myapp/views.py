from django.shortcuts import render

def index(request):
	return render(request, 'index.html')

def golden(request):
	return render(request, 'golden.html')

def bug(request):
	return render(request, 'bug.html')

def cob(request):
	return render(request, 'cob.html')

def tonnm(request):
	return render(request, 'tonnm.html')